const papeis = {
     "Alta Alvura 75g": 0.05,
     "Alta Alvura 90g": 0.06,
     "Alta Alvura 120g": 0.075,
     "Alta Alvura 150g": 0.09,
     "Alta Alvura 180g": 0.115,
     "Alta Alvura 240g": 1.55,
     "Avena 80g": 0.055,
     "Avena 90g": 0.06,
     "Chambril 120g": 0.08,
     "Couchê Brilho 90g": 0.035,
     "Couchê Brilho 95g": 0.044,
     "Couchê Brilho 115g": 0.047,
     "Couchê Brilho 150g": 0.055,
     "Couchê Brilho 170g": 0.077,
     "Couchê Brilho 180g": 0.09,
     "Couchê Brilho 210g": 0.105,
     "Couchê Brilho 230g": 0.11,
     "Couchê Brilho 240g": 0.115,
     "Couchê Fosco 90g": 0.045,
     "Couchê Fosco 95g": 0.05,
     "Couchê Fosco 115g": 0.055,
     "Couchê Fosco 150g": 0.08,
     "Couchê Fosco 170g": 0.09,
     "Couchê Fosco 210g": 0.12,
     "Ivory Cold 58g": 0.065,
     "Ivory Cold 90g": 0.09,
     "Ivory Slim 65g": 0.045,
     "Ivory Slim 75g": 0.055,
     "Ivory Slim Speed 65g": 0.05,
     "Hi-Kote Fosco 90g": 0.04,
     "Hi-Kote Fosco 115g": 0.0475,
     "Hi-Kote Fosco 150g": 0.07,
     "Hi-Kote Fosco 170g": 0.085,
     "Hi-Kote Fosco 250g": 0.115,
     "Hi-Kote Brilho 115g": 0.05,
     "Fit Gloss Brilho 70g": 0.0275,
     "Fit Gloss Brilho 80g": 0.035,
     "Fit Gloss Brilho 90g": 0.04,
     "Fit Silk Fosco 70g": 0.03,
     "Fit Silk Fosco 80g": 0.035,
     "Fit Silk Fosco 90g": 0.04,
     "Fit Silk Fosco 115g": 0.08,
     "Lumisilk 90g": 0.04, 
     "Lumisilk 115g": 0.05,
     "Lumisilk 150g": 0.065,
     "Lumisilk 170g": 0.075,
     "Lux Cream 70g": 0.06,
     "Magno Satin 90g": 0.035,
     "Magno Satin 115g": 0.05,
     "Magno Satin 150g": 0.06,
     "Magno Satin 170g": 0.07,
     "Magno Star 75g": 0.03,
     "Magno Star 90g": 0.035,
     "Magno Star 115g": 0.0425,
     "Magno Star 150g": 0.06,
     "Magno Star 170g": 0.065,
     "Offset 50g": 0.0335,
     "Offset 56g": 0.037,
     "Offset 63g": 0.0425,
     "Offset 70g": 0.045,
     "Offset 75g": 0.05,
     "Offset 90g": 0.06,
     "Pólen Bold 70g": 0.06,
     "Pólen Bold 90g": 0.085,
     "Pólen Natural 80g": 0.05,
     "Pólen Soft 80g": 0.055,
     "Reciclato 75g": 0.05,
     "Reciclato 90g": 0.0575,
     "Reciclato 120g": 0.077,
  
};

function limparResultado() {
    const resultado = document.getElementById('resultado');
    const alerta = document.getElementById('alerta');
    resultado.textContent = '';
    alerta.textContent = '';
}

const tipoPapelSelect = document.getElementById('tipoPapel');

const optionInformativa = document.createElement('option');
optionInformativa.value = "";
optionInformativa.disabled = true;
optionInformativa.selected = true;
optionInformativa.textContent = "Selecione o papel";
tipoPapelSelect.appendChild(optionInformativa);

for (const [nome, indice] of Object.entries(papeis)) {
    const option = document.createElement('option');
    option.value = nome;
    option.textContent = `${nome} (índice ${indice})`;
    tipoPapelSelect.appendChild(option);
}

function calcularLombada() {
    const numPaginas = parseInt(document.getElementById('numPaginas').value);
    const tipoPapel = document.getElementById('tipoPapel').value;
    const indice = papeis[tipoPapel];
    const acabamento = parseInt(document.getElementById('acabamento').value);
    const limiteMaximo = 70;

    const resultado = document.getElementById('resultado');
    const alerta = document.getElementById('alerta');
  
    alerta.textContent = "";
    resultado.textContent = "";

    if (numPaginas > 500 && acabamento !== 0 ) {
        alerta.textContent = 
            "A partir de 500 páginas é recomendado a confecção de um boneco para a medição da lombada. Favor contatar o atendimento caso haja dúvidas.";
        alerta.style.color = 'orange';
        alerta.style.fontSize = '16px';
        alerta.style.fontFamily = 'Arial';
    } else {
        alerta.textContent = "";
    }

    if (!isNaN(numPaginas) && indice) {
        let lombada = numPaginas * indice + acabamento;
       
      const decimalParte = lombada % 1;
      if (decimalParte <= 0.20) {
        lombada = Math.floor(lombada);
    } else {
        lombada = Math.ceil(lombada);
    }
      
        if (numPaginas > 500 && acabamento === 0) {
            lombada += 2;
        }
      
        if (numPaginas > 300 && acabamento === 1) {
            lombada += 2;
        }
      
        let resultadoText = `A lombada do livro será de ${lombada.toFixed(2)} mm.`;

        if (lombada > limiteMaximo) {
            resultadoText += ` <span class="avisolimite">Aviso: O limite máximo de ${limiteMaximo} mm foi ultrapassado!</span>`;
        }

        if (acabamento === 5 && lombada < 8) {
            alerta.textContent = "Para acabamento Capa Dura, a lombada deve ser no mínimo 8mm.";
            return;
        }

        resultado.innerHTML = resultadoText;
    } else {
        resultado.textContent = 'Por favor, insira um número válido de páginas.';
    }
}